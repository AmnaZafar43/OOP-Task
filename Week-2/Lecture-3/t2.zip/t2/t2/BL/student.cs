﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t2.BL
{
    class student
    {
        public string name;
        public int roll;
        public float gpa;
        public string hostelite;
        public string department;
    }
}
