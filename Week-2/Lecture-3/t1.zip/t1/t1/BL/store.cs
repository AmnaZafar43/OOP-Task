﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t1.BL
{
    class store
    {
        public string name = "";
        public int id = 0;
        public int price = 0;
        public string category = "";
        public string brand = "";
        public string country = "";
    }
}
