﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using t3.BL;

namespace t3
{
    class Program
    {
        static void Main(string[] args)
        {
            int e_time,rem_time;
            clockType time = new clockType();
            clockType time1 = new clockType(4);
            clockType time2 = new clockType(4, 5);
            clockType time3 = new clockType(4, 5, 2);
            clockType t = new clockType();
            clockType t1 = new clockType();
            Console.WriteLine("\n\t");
            Console.WriteLine("  Empty time\t" + time.hour + ":" + time.mint + ":" + time.second);
            Console.WriteLine("  Hour time\t" + time1.hour + ":" + time.mint + ":" + time.second);
            Console.WriteLine("  Minute time\t" + time2.hour + ":" + time2.mint + ":" + time.second);
            Console.WriteLine("  Full time\t" + time3.hour + ":" + time3.mint + ":" + time3.second);
            e_time = t.elapsed_time(4, 5, 2);
            Console.WriteLine("  Elapsed time in second is\t" + e_time);
            rem_time = t1.remaining_time(4, 5, 2);
            Console.WriteLine("  Reamaining time in second is\t" + rem_time);
            Console.ReadKey();

        }
    }
}
