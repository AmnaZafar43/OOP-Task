﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t3.BL
{
    class clockType
    {
        public int hour;
        public int mint;
        public int second;
        public clockType()
        {
            hour = 0;
            mint = 0;
            second = 0;
        }
        public clockType(int h)
        {
            hour = h;
        }
        public clockType(int h,int m)
        {
            hour = h;
            mint = m;
        }
        public clockType(int h,int m,int s)
        {
            hour = h;
            mint = m;
            second = s;
        }
        public int elapsed_time(int h,int m,int s)
        {
            int elapse=0;
            elapse = (h * 3600) + (m * 60) + (s);
            return elapse;
        }
        public int remaining_time(int h,int m,int s)
        {
            int rem_time;
            int time_hour;
            time_hour = (24 - h);
            rem_time = (time_hour * 3600) + (m * 60) + (s);            
            return rem_time;
        }
    }
}
