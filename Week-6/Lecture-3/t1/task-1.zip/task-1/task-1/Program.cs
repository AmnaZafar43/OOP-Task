﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using task_1.BL;
using task_1.UI;

namespace task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            UI.takeInput.takeCoordinates();
        }
    }
}
